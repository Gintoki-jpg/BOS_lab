#include"Dmm.h"

int main()
{
        set_heap(100*sizeof(int));
        //printf("main is running...\n"); //if we add this annotate,our program will fail
	int* p = (int*)malloc(10 * sizeof(int));
	if (p == NULL)
	{
		printf("内存开辟失败！\n");
	}
	else
	{
		printf("内存开辟成功，请依次输入数组数据：\n");
		for(int i = 0; i <= 4; i++){
            scanf("%d",&p[i]);}
        for(int i = 0; i <= 4; i++){
            printf("p[%d] = %d\n", i,p[i]);}

		int *ptr = (int*)realloc(p,5*sizeof(int));
		if(ptr!=NULL){
            p=ptr;
            ptr=NULL;
            printf("内存扩容成功！\n");
            for(int i = 0; i <= 4; i++){
                printf("p[%d] = %d\n", i,p[i]);}

		}
		else{
            printf("内存扩容失败！\n");
		}
		free(p);
        p=NULL;
		printf("内存释放成功！\n");
	}
	return 0;

}
