//these three functions are right,i test them one by one,the next thing is to modify Dmm.c
#include "Dmm.h"

t_block heap_start = NULL;
t_block heap_end = NULL;
t_block heap_break = NULL;

void set_heap(size_t heap_size){
    printf("set_heap is running...\n");
    heap_start = (t_block)sbrk(0);
    printf("heap_start is %p\n",heap_start);
    heap_break = heap_start;            //��ʼ��ȫ�ֱ���heap_break
    if(sbrk(heap_size)==(void*)-1){
        printf("Error:set_heap fail!\n");
        return;
    }
    else{
        printf("set_heap suc!\n");
        heap_end = (t_block)sbrk(0);
        printf("heap_end is %p\n",heap_end);
    }
}

int heap_brk(void *heap_addr){
    if(heap_start<=(t_block)heap_addr&&(t_block)heap_addr<=(t_block)heap_end){
        heap_break = heap_addr;
        return 0;
    }
    else{
        return -1;
    }
}

void *heap_sbrk(size_t heap_inc){
    if(heap_start<=(t_block)((size_t *)heap_break+heap_inc)&&(t_block)((size_t *)heap_break+heap_inc)<=(t_block)heap_end){
        heap_break = (t_block)((size_t *)heap_break+heap_inc);
        return (t_block)((size_t*)heap_break-heap_inc);
    }
    else{
        return NULL;
    }
}

