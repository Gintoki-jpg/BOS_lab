#include"Dmm.h"
#include"main.h"
extern struct thread_struct *current;         
extern struct thread_struct *task[THR_TASKS]; 
//In this program,we test thread rather than scanf(beacause it has something wrong...)

void fun1()
{ 
    int i = 1;
    while (1)
    {
        int* p = (int*)malloc(i * sizeof(char));
	if (p == NULL)
	{
	    printf("ran out of memory！\n");
            return;
	}
	else
	{
	    printf("malloc %d Byte succeed!\n",i);
	}
        i=i*2;
        mysleep(1);
    }
}


int main()
{       
        set_heap(32768*sizeof(int));//we should note that our thread also need heap memory,so we can't calculate memory presicely
        //printf("main is running...\n"); //if we add this annotate,our program will fail
        
    	int tid1;
    	thread_create(&tid1, fun1);
    	printf("Thread_ %d has been created\n", tid1);
    	thread_join(tid1);
	
        return 0;

}
