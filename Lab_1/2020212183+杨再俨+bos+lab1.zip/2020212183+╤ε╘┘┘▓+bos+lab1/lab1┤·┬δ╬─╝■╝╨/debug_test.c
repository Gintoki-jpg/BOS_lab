#include "main.h"

extern struct thread_struct *current;         
extern struct thread_struct *task[THR_TASKS]; 

void fun1()
{
    int i = 2;
    while (i--)
    {
        printf("thread_ %d is running----it's status is %d\n",current->id,current->status);
        mysleep(1);
    }
}

void fun2()
{
    int i = 3;
    while (i--)
    {
        printf("thread_ %d is running----it's status is %d\n",current->id,current->status);
        mysleep(1);
    }
}


int main()
{

    int tid1, tid2, tid3, tid4;
    thread_create(&tid1, fun1);
    printf("Thread_ %d has been created\n", tid1);
    thread_create(&tid2, fun2);
    printf("Thread_ %d has been created\n", tid2);
    printf("<====================================>\n");
    thread_join(tid1);
    thread_join(tid2);
    return 0;
}
