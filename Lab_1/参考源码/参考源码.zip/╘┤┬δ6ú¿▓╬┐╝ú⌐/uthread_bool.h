#ifndef _uthread_bool_h_
#define _uthread_bool_h_


/* assume these will be right if they are defined */

typedef int bool;

#ifndef true
#define true 1
#endif

#ifndef false
#define false 0
#endif

#endif
